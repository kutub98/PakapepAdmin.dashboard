//  modal
const modal = document.getElementById("myModal");

// modal button
const btn = document.getElementById("myBtn");

const span = document.getElementsByClassName("close")[0];

btn.onclick = function () {
  modal.style.display = "block";
};

span.onclick = function () {
  modal.style.display = "none";
};

window.onclick = function (event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
};

const loginHandle = document.getElementById("loginHandle");
loginHandle.addEventListener("submit", (e) => {
  e.preventDefault();
  const userName = document.getElementById("username");
  const userPassword = document.getElementById("password");
  const ConfirmPassword = document.getElementById("Confirmpassword");
  const myBtn = document.getElementById("myBtn");
  const loginPage = document.getElementById("loginPage");
  const dashboard = document.getElementById("dashboard");

  const username = "alimChowdury";
  const password = "pkapepe-4592";
  const userConfirmPassword = password;
  if (userName.value === username && userPassword.value === password && ConfirmPassword.value === userConfirmPassword) {
    myBtn.style.display = "none";
    loginPage.style.display = "none";
    dashboard.style.display = "block";
  } else {
    return alert("Sorry your password is wrong");
  }
});
